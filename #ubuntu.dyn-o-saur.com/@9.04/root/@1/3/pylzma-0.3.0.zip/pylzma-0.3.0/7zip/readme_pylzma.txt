This directory contains only a part of the original LZMA sources.

Some files were modified and are not an exact replica of the original
files in order to be compiled with the PyLZMA library.

If you are looking for the original LZMA sources, please visit the
official homepage at http://www.7-zip.org.

-- 
Joachim Bauch / mail@joachim-bauch.de
