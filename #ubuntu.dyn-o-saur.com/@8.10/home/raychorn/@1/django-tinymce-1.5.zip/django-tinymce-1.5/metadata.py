name = 'tinymce'
authors = 'Joost Cassee'
version = '1.5'
release = version
