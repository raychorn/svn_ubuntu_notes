:mod:`tz_util` -- MOVED
=======================

.. module:: pymongo.tz_util

This module has been deprecated in favor of
:mod:`bson.tz_util`. Please use that module instead.

.. versionchanged:: 1.9
   Deprecated.
