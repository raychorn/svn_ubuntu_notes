:mod:`son` -- MOVED
===================

.. module:: pymongo.son

This module has been deprecated in favor of :mod:`bson.son`. Please
use that module instead.

.. versionchanged:: 1.9
   Deprecated.
