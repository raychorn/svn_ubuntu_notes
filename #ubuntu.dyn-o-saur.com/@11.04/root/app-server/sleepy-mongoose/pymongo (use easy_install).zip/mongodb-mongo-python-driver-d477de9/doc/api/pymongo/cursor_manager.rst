:mod:`cursor_manager` -- Managers to handle when cursors are killed after being closed
======================================================================================

.. automodule:: pymongo.cursor_manager
   :synopsis: Managers to handle when cursors are killed after being closed
   :members:
