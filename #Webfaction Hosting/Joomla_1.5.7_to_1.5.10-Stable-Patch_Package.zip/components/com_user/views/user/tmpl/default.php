<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>
	<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<?php echo $this->escape($this->params->get('page_title')); ?>
	</div>
<?php endif; ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
	<td>
		<?php echo nl2br($this->params->get('welcome_desc', JText::_( 'WELCOME_DESC' ))); ?>
	</td>
</tr>
</table>
